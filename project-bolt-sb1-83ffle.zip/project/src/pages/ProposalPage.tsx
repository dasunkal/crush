import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { Heart, HeartCrack, Send, Gift, Music, Coffee } from 'lucide-react';
import { collection, addDoc } from 'firebase/firestore';
import { db } from '../firebase';
import Confetti from 'react-confetti';

const steps = [
  {
    id: 1,
    title: "Hey there! 👋",
    content: "Before I ask you something important, let me share a few things...",
    icon: Heart
  },
  {
    id: 2,
    title: "Remember when...",
    content: "We first met? That moment has been special to me ever since.",
    icon: Coffee
  },
  {
    id: 3,
    title: "You know...",
    content: "Every time I see you, my heart skips a beat and my day gets brighter.",
    icon: Music
  },
  {
    id: 4,
    title: "And now...",
    content: "I've gathered all my courage to ask you something very special.",
    icon: Gift
  }
];

function ProposalPage() {
  const [currentStep, setCurrentStep] = useState(1);
  const [answer, setAnswer] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleAnswer = (selectedAnswer: string) => {
    setAnswer(selectedAnswer);
    if (selectedAnswer === 'yes') {
      setShowConfetti(true);
      setTimeout(() => setShowConfetti(false), 5000);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!answer) return;

    setIsSubmitting(true);
    try {
      await addDoc(collection(db, 'responses'), {
        answer,
        message,
        timestamp: new Date().toISOString()
      });
      navigate('/dashboard');
    } catch (error) {
      console.error('Error submitting response:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      {showConfetti && <Confetti />}
      <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-lg bg-white rounded-2xl shadow-xl overflow-hidden"
        >
          <div className="bg-gradient-to-r from-pink-500 to-purple-500 p-6">
            <div className="flex justify-center">
              <motion.div
                animate={{ scale: [1, 1.2, 1] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="w-16 h-16 bg-white rounded-full flex items-center justify-center"
              >
                {currentStep <= steps.length ? (
                  <steps[currentStep - 1].icon className="h-8 w-8 text-pink-500" />
                ) : (
                  <Heart className="h-8 w-8 text-pink-500" />
                )}
              </motion.div>
            </div>
          </div>

          <div className="p-6 space-y-6">
            <AnimatePresence mode="wait">
              {currentStep <= steps.length ? (
                <motion.div
                  key={currentStep}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="text-center space-y-4"
                >
                  <h2 className="text-2xl font-bold text-gray-800">
                    {steps[currentStep - 1].title}
                  </h2>
                  <p className="text-gray-600">
                    {steps[currentStep - 1].content}
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={handleNext}
                    className="px-6 py-3 bg-pink-500 text-white rounded-full hover:bg-pink-600 transition-colors"
                  >
                    Continue
                  </motion.button>
                </motion.div>
              ) : (
                <motion.div
                  key="proposal"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="text-center">
                    <h2 className="text-3xl font-bold text-gray-800 mb-4">
                      Will you be my Valentine?
                    </h2>
                    <div className="flex flex-col sm:flex-row justify-center gap-4">
                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleAnswer('yes')}
                        className={`flex items-center justify-center space-x-2 px-6 py-3 rounded-full transition-all ${
                          answer === 'yes'
                            ? 'bg-pink-500 text-white'
                            : 'bg-pink-100 text-pink-500 hover:bg-pink-200'
                        }`}
                      >
                        <Heart className="h-5 w-5" />
                        <span>Yes</span>
                      </motion.button>

                      <motion.button
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleAnswer('no')}
                        className={`flex items-center justify-center space-x-2 px-6 py-3 rounded-full transition-all ${
                          answer === 'no'
                            ? 'bg-gray-500 text-white'
                            : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                        }`}
                      >
                        <HeartCrack className="h-5 w-5" />
                        <span>No</span>
                      </motion.button>
                    </div>
                  </div>

                  {answer && (
                    <motion.form
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      onSubmit={handleSubmit}
                      className="space-y-4"
                    >
                      <div>
                        <label
                          htmlFor="message"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Leave a message
                        </label>
                        <textarea
                          id="message"
                          rows={4}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-pink-500 focus:border-pink-500"
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          placeholder="Write something sweet..."
                        />
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        type="submit"
                        disabled={isSubmitting}
                        className="w-full flex items-center justify-center space-x-2 px-4 py-3 border border-transparent rounded-lg shadow-sm text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 disabled:opacity-50"
                      >
                        <Send className="h-5 w-5" />
                        <span>Send Response</span>
                      </motion.button>
                    </motion.form>
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </motion.div>
      </div>
    </>
  );
}

export default ProposalPage;